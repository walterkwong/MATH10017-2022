#include <stdio.h>
#include <stdlib.h>
#include <math.h>

class Problem
{
    // width of the search space, or the step size in gradient descent algorithm
    double epsilon; 
    double x0; // initial guess
    
    double f(double x) // f(x) 
    {
        return sin(x / 2) + cos(x / 4);
    }

    // solve the subproblme
    // argmax_x\in [xt-epsilon, xt+epsilon] f(x)
    double subproblem(double xt, double epsilon)
    {
        // TODO: solve the subproblem
    }

public:
    Problem(double eps, double initial_guess)
    {
        // TODO: intialize fields
    }

    void solve()
    {
        // TODO: search for the maximizer of f(x), using greedy algorithm
        // Do not forget to print out the final result. 
    }
};


int main()
{
    // do not change 
    Problem p(0.5, -4);
    p.solve();

    // TODO: uncomment the following line, after implementing GAsolve()
    // p.GAsolve();
}