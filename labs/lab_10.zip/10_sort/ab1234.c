#include <stdio.h>
#include <stdlib.h>


//TODO: 1. write a print function, takes an array as an input, and print out its contents. 


//TODO: 2. write your swap function below. 


//TODO: 3. write your find_max_idx function below.


//TODO: 4. write your sort function 1.0 below. 


//TODO: 5. write your sort function 2.0 below, use function name sort_v2.


void main()
{
    //TODO: COMMENT OUT unnessary lines below 
    // so that you can test your functions ONE BY ONE!

    // test your swap functions here. 
    printf("test swap function-----------------\n");
    int a[] = {2,3,5};
    swap(a, 0, 1);    
    print(a, 3); // should print out 3,2,5

    printf("test find_max_idx function-----------------\n");
    // test your find_max_idx function here.
    int max_id = find_max_idx(a, 3); // should print out 2
    printf("max_id: %d", max_id);

    printf("test sort function-----------------\n");
    // test your sort function here.
    int b[] = {5,3,2,1,2,4};
    sort(b, 6);
    print(b, 6);

    printf("test sort v2-----------------\n");
    sort_v2(b, 6);
    print(b, 6); 

    // Does the output fits your understanding of these sorting algorithms? 

}