#include <stdio.h>
#include <stdlib.h>


//TODO: 1. write a print function, takes an array as an input, and print out its contents. 


//TODO: 2. write your swap function below. 


//TODO: 3. write your find_max_idx function below.


//TODO: 4. write your sort function 1.0 below. 


//TODO: 5. write your sort function 2.0 below, use function name sort_v2.


void main()
{
    // test your swap functions here. 
    int a[] = {2,3,5};
    swap(a, 0, 1);
    
    print(a, 3); // should print out 3,2,5

    // test your find_max_idx function here.
    int max_id = find_max_idx(a, 3); // should print out 2
    printf("max_id: %d", max_id);

    // test your sort function here.

    int b[] = {5,3,2,4,2,1999,-1999};
    sort(b, 7);
    print(b, 7); // should print out -1999,2,2,3,4,5,1999

}