library(imager)
img <- load.image("UoB.jpg")
img <- grayscale(img)
M <- as.matrix(img)

# writr your code here
